package hr.javafx.hotels.lanachotelabosnjakpr.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

public class StandardniHotel extends Hotel implements Serializable {

    private RazinaObroka kolHr;

    public StandardniHotel(Integer id, String imeHotela, String grad, BigDecimal price, LocalDate datumPrijave, Zvjezdice zvjezdice, Set<Radnik> listaRadnika, RazinaObroka kolHr) {
        super(id, imeHotela, grad, price, datumPrijave, zvjezdice, listaRadnika);
        this.kolHr = kolHr;
    }

    public RazinaObroka getRazinaPrehrane() {
        return kolHr;
    }

    public void setRazinaObroka(RazinaObroka kolGr) {
        this.kolHr = kolGr;
    }
}
