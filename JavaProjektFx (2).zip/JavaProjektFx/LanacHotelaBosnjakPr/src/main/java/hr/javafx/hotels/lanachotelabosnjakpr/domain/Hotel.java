package hr.javafx.hotels.lanachotelabosnjakpr.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;
import java.util.Objects;

public abstract class Hotel extends Entity implements Serializable {

    private String imeHotela;
    private String grad;
    private BigDecimal price;
    private LocalDate datumPrijave;
    private Zvjezdice zvjezdice;

    private Set<Radnik> listaRadnika;

    public Hotel(Integer id, String imeHotela, String grad, BigDecimal price, LocalDate datumPrijave, Zvjezdice zvjezdice, Set<Radnik> listaRadnika) {
        super(id);
        this.imeHotela = imeHotela;
        this.grad = grad;
        this.price = price;
        this.datumPrijave = datumPrijave;
        this.zvjezdice = zvjezdice;
        this.listaRadnika = listaRadnika;
    }

    public String getImeHotela() {
        return imeHotela;
    }

    public void setImeHotela(String imeHotela) {
        this.imeHotela = imeHotela;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDate getDatumPrijave() {
        return datumPrijave;
    }

    public void setDatumPrijave(LocalDate datumPrijave) {
        this.datumPrijave = datumPrijave;
    }

    public Zvjezdice getZvjezdice() {
        return zvjezdice;
    }

    public void setZvjezdice(Zvjezdice zvjezdice) {
        this.zvjezdice = zvjezdice;
    }

    public Set<Radnik> getListaRadnika() {
        return listaRadnika;
    }

    public void setListaRadnika(Set<Radnik> listaRadnika) {
        this.listaRadnika = listaRadnika;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Hotel hotel)) return false;
        return Objects.equals(getImeHotela(), hotel.getImeHotela()) && Objects.equals(getGrad(), hotel.getGrad()) && Objects.equals(getPrice(), hotel.getPrice()) && Objects.equals(getDatumPrijave(), hotel.getDatumPrijave()) && getZvjezdice() == hotel.getZvjezdice();
    }

    @Override
    public int hashCode() {
        return Objects.hash(imeHotela, grad, price);
    }

    @Override
    public String toString() {
        return "Hotel{ " +
                "imeHotela= '" + imeHotela + '\'' +
                ", grad='" + grad + '\'' +
                ", price= " + price +
                ", datumPrijave= " + datumPrijave +
                ", hotelTypeCategory = " + zvjezdice +
                '}';
    }
}
