package hr.javafx.hotels.lanachotelabosnjakpr.domain;

import java.io.Serializable;

public record RazinaObroka(Integer id, Integer kolicina, VrstaObroka vrstaObroka) implements Serializable {

    @Override
    public Integer id() {
        return id;
    }

    @Override
    public String toString() {
        return vrstaObroka.name() + " - " + kolicina;
    }

    @Override
    public Integer kolicina() {
        return kolicina;
    }

    @Override
    public VrstaObroka vrstaObroka() {
        return vrstaObroka;
    }
}
