package hr.javafx.hotels.lanachotelabosnjakpr.domain;

public class Radnik <T> {

    private String ime;
    private String prezime;

    private T opisPosla;

    private Integer id;

    public Radnik(String ime, String prezime, T opisPosla) {
        this.ime = ime;
        this.prezime = prezime;
        this.opisPosla = opisPosla;
    }

    public Radnik(String ime, String prezime, T opisPosla, Integer id) {
        this.ime = ime;
        this.prezime = prezime;
        this.opisPosla = opisPosla;
        this.id = id;
    }

    @Override
    public String toString() {
        return ime + " "  + prezime + " " + opisPosla;
    }

    public Integer getId() {
        return id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getOpisPosla() {
        return opisPosla.toString();
    }

    public void setOpisPosla(T opisPosla) {
        this.opisPosla = opisPosla;
    }
}
