package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.RazinaObroka;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.VrstaObroka;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UnosRazineObrokaController {

    @FXML
    private TextField razinaObrokaTextField;

    @FXML
    private ComboBox<String> unosVrsteObroka;

    public void initialize() {

        List<String> obrokList = new ArrayList<>();
        obrokList.add(VrstaObroka.MESO.name());
        obrokList.add(VrstaObroka.RIBA.name());
        obrokList.add(VrstaObroka.VEGE.name());

        unosVrsteObroka.setItems(FXCollections.observableList(obrokList));

    }

    public void unosObroka() {
        String razinaObrokaText = razinaObrokaTextField.getText();

        String vrstaObroka = unosVrsteObroka.getValue();


        if (razinaObrokaText.isEmpty() || vrstaObroka.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesite sve podatke");

            alert.showAndWait();

            return;
        }

        Integer konvertiranaKol;
        try {
            konvertiranaKol = Integer.parseInt(razinaObrokaText);

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesie broj!");
            alert.showAndWait();
            return;

        }

        VrstaObroka odabranaVrstaObroka = VrstaObroka.fromName(vrstaObroka);

        RazinaObroka razObr = new RazinaObroka(0, konvertiranaKol, odabranaVrstaObroka);
        if (DatabaseUtils.saveRazinaObroka(razObr) == true) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Unos uspješan!");
            alert.setContentText("Podaci su uspješno uneseni");
            alert.showAndWait();
            FileUtils fileUtils = new FileUtils();
            fileUtils.spremiPromjenu(new Promjena("Unjeli smo novi obrok" + " " + vrstaObroka, LocalDate.now(), LoginController.userRole));

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Podaci nisu uneseni, došlo je do greške");
            alert.showAndWait();
        }

    }


}
