package hr.javafx.hotels.lanachotelabosnjakpr.exceptions;

public class PrazanFilterRadnikaException extends RuntimeException{
    public PrazanFilterRadnikaException(String message) {
        super(message);
    }

    public PrazanFilterRadnikaException(String message, Throwable cause) {
        super(message, cause);
    }

    public PrazanFilterRadnikaException(Throwable cause) {
        super(cause);
    }
}
