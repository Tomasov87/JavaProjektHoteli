package hr.javafx.hotels.lanachotelabosnjakpr.exceptions;

public class NedovoljnoRadnikaException extends Exception{
    public NedovoljnoRadnikaException(String message) {
        super(message);
    }

    public NedovoljnoRadnikaException(String message, Throwable cause) {
        super(message, cause);
    }

    public NedovoljnoRadnikaException(Throwable cause) {
        super(cause);
    }
}
