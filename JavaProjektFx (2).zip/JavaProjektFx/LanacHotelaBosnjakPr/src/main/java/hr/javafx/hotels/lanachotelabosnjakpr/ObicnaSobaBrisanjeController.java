package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.Hotel;
//import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;

import java.util.List;

public class ObicnaSobaBrisanjeController {


    @FXML
        private ListView<Hotel> sobeListView;

        private List<Hotel> hotels;

        public void initialize() {
            // Učitajte listu hotela prilikom pokretanja prozora
            hotels = null;
            // Prikazati listu hotela u ListView-u
            sobeListView.getItems().addAll(hotels);
        }

        @FXML
        public void obrisiSobu() {
            // Dohvati odabrani hotel za brisanje
            Hotel selectedHotel = sobeListView.getSelectionModel().getSelectedItem();
            if (selectedHotel != null) {
                // Ukloni odabrani hotel iz liste hotela
                hotels.remove(selectedHotel);
                // Ažurirajte prikaz u ListView-u
                sobeListView.getItems().remove(selectedHotel);
                // Spremi ažuriranu listu hotela
                //FileUtils.saveHotels(hotels);
                // Obavijestite korisnika da je soba uspješno obrisana
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Brisanje sobe");
                //alert.setHeaderText(null);
                alert.setContentText("Soba je uspješno obrisana.");
                alert.showAndWait();
            } else {
                // Ako nije odabrana soba, obavijestite korisnika
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Brisanje sobe");
                alert.setHeaderText(null);
                alert.setContentText("Molimo odaberite sobu koju želite obrisati.");
                alert.showAndWait();
            }

}
}
