package hr.javafx.hotels.lanachotelabosnjakpr;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class IzbornikController {


    private static final Logger log = LoggerFactory.getLogger(IzbornikController.class);
    public MenuItem promjene;

    @FXML
    public void initialize(){
        if (!LoginController.userRole.equals("admin")){
            promjene.setVisible(false);
        }
    }

    public void unosLux(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("luksuzniHotelUnos.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void pregledLux(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("LuksuzniHotelPrikaz.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void unosStan(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("unosStandardniHotel.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void pregledStan(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("standardniHotelPregled.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void unosRadnici(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("radniciUnos.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void pregledRadnici(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("pregledRadnika.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void unosJela(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("unosRazineObroka.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void pregledJela(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("pregledJela.fxml"));

        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }

    public void pregledPromjena(ActionEvent actionEvent) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("pregledPromjena.fxml"));
       // System.out.println("haha");
        try {
            Scene  scene = new Scene(fxmlLoader.load());
            HelloApplication.getMainStage().setTitle("Hotelski ekran!");
            HelloApplication.getMainStage().setScene(scene);
            HelloApplication.getMainStage().sizeToScene();
            HelloApplication.getMainStage().show();
        } catch (IOException e) {
            log.error("Neuspjesno loadanje file-a",e);
        }
    }
}
