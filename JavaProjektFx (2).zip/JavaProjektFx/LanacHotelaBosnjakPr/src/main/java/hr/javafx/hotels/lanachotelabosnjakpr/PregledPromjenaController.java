package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.util.StringConverter;

import java.util.*;

public class PregledPromjenaController {

    @FXML
    ListView<String> listViewPromjene;

    private final Map<String, List<Promjena>> promjeneMap = new HashMap<>();

    public void initialize() {
        FileUtils fileUtils = new FileUtils();
        List<Promjena> promjeneList = fileUtils.dohvatiPromjene();
        for (Promjena promjena : promjeneList) {
            String user = promjena.getUser();
            if (!promjeneMap.containsKey(user)) {
                promjeneMap.put(user, new ArrayList<>());
            }
            promjeneMap.get(user).add(promjena);
        }

        ObservableList<String> users = FXCollections.observableArrayList(promjeneMap.keySet());
        listViewPromjene.setItems(users);

        listViewPromjene.setCellFactory(param -> new TextFieldListCell<>(new StringConverter<String>() {
            @Override
            public String toString(String user) {
                List<Promjena> promjene = promjeneMap.get(user);
                if (promjene != null && !promjene.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(user).append(":\n");
                    for (Promjena promjena : promjene) {
                        sb.append("  - ").append(promjena.getVrijeme()).append(": ").append(promjena.getOpisPromjene()).append("\n");
                    }
                    return sb.toString();
                }
                return user;
            }

            @Override
            public String fromString(String string) {
                return string;
            }
        }));
    }
}
