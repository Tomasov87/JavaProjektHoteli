package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.LuksuzniHotel;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class LuksuzniHotelPrikazController {


    private static final Logger log = LoggerFactory.getLogger(LuksuzniHotelPrikazController.class);
    @FXML
    TableColumn<LuksuzniHotel, String> imeColumn;

    @FXML
    TableColumn<LuksuzniHotel, String> gradColumn;

    @FXML
    TableColumn<LuksuzniHotel, String> cijenaColumn;

    @FXML
    TableColumn<LuksuzniHotel, String> datumColumn;

    @FXML
    TableColumn<LuksuzniHotel, Integer> zvjezdiceColumn;

    @FXML
    TableColumn<LuksuzniHotel, String> kvadratiColumn;

    @FXML
    TableView<LuksuzniHotel> tablicaHotela;

    @FXML
    private TextField zvjezdiceFilter;
    @FXML
    private TextField cijenaFilter;

    @FXML
    private TextField imeHotelaFilter;

    List<LuksuzniHotel> listaLuxHotela;

    private final ExecutorService executorService = Executors.newFixedThreadPool(2);

    @FXML
    public void initialize() {
        Future<List<LuksuzniHotel>> future = executorService.submit(new Callable<List<LuksuzniHotel>>() {
            @Override
            public List<LuksuzniHotel> call() {
                return DatabaseUtils.getLuksuzniHotel();
            }
        });

        try {
            listaLuxHotela = future.get();
            imeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getImeHotela()));
            gradColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getGrad()));
            cijenaColumn.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().getPrice().toString()));
            datumColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDatumPrijave().toString()));
            zvjezdiceColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getZvjezdice().getBrojZvj()).asObject());
            kvadratiColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getBrojKvadrata()).asObject().asString());

            ObservableList<LuksuzniHotel> observableLuxHotel = FXCollections.observableArrayList(listaLuxHotela);
            tablicaHotela.setItems(observableLuxHotel);
        } catch (Exception e) {
            log.error("Neuspjesno postavljanje parametra tablice luksuznih hotela",e);
        }
    }

    public void filterLuksHotele() {
        String imeFilter = imeHotelaFilter.getText();
        String cijenaFilt = cijenaFilter.getText();
        String zvjFilter = zvjezdiceFilter.getText();

        if (listaLuxHotela.isEmpty()) {
            return;
        }

        if (imeFilter.isEmpty()) {
            imeFilter = "";
        }

        if (cijenaFilt.isEmpty()) {
            cijenaFilt = "";
        }

        if (zvjFilter.isEmpty()) {
            zvjFilter = "";
        }

        String finalImeFilter = imeFilter;
        String finalCijenaFilter = cijenaFilt;
        String finalZvjFilter = zvjFilter;

        Future<List<LuksuzniHotel>> future = executorService.submit(new Callable<List<LuksuzniHotel>>() {
            @Override
            public List<LuksuzniHotel> call() {
                List<LuksuzniHotel> filtriranaLista;

                BigDecimal konvCijena = null;
                Integer konvZvj = null;
                try {
                    if (!finalCijenaFilter.isEmpty()) {
                        konvCijena = new BigDecimal(finalCijenaFilter);
                    }
                    if (!finalZvjFilter.isEmpty()) {
                        konvZvj = Integer.parseInt(finalZvjFilter);
                    }
                } catch (Exception e) {
                    return new ArrayList<>();
                }

                filtriranaLista = listaLuxHotela.stream().filter(x -> x.getImeHotela().contains(finalImeFilter)).collect(Collectors.toList());

                BigDecimal finalKonvCijena = konvCijena;
                if (finalKonvCijena != null) {
                    filtriranaLista = filtriranaLista.stream().filter(x -> x.getPrice().equals(finalKonvCijena)).collect(Collectors.toList());
                }

                Integer finalKonvZvj = konvZvj;
                if (finalKonvZvj != null) {
                    filtriranaLista = filtriranaLista.stream().filter(x -> x.getZvjezdice().getBrojZvj().equals(finalKonvZvj)).collect(Collectors.toList());
                }

                return filtriranaLista;
            }
        });

        try {
            List<LuksuzniHotel> filtriranaLista = future.get();
            if (filtriranaLista == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Krivi unos!");
                alert.setContentText("Molimo Vas unesite broj!");
                alert.showAndWait();
                return;
            }

            ObservableList<LuksuzniHotel> filtriranaObservableLista = FXCollections.observableArrayList(filtriranaLista);
            tablicaHotela.setItems(filtriranaObservableLista);
        } catch (Exception e) {
            log.error("Neuspjesno dohvacanje filtrirane liste luskuznih hotela",e);
        }
    }

    @FXML
    private void onDeleteHotel() {
        Alert popup = new Alert(Alert.AlertType.CONFIRMATION);
        popup.setTitle("Confirmation");
        popup.setContentText("Are you sure you want to delete the hotel?");
        popup.showAndWait().ifPresent(new Consumer<ButtonType>() {
            @Override
            public void accept(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {
                    LuksuzniHotel selectedHotel = tablicaHotela.getSelectionModel().getSelectedItem();
                    if (selectedHotel != null) {
                        boolean success = DatabaseUtils.deleteLuksuzniHotel(selectedHotel);
                        if (success) {
                            // Remove from the table
                            listaLuxHotela.remove(selectedHotel);
                            tablicaHotela.getItems().remove(selectedHotel);
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Hotel deleted");
                            alert.setContentText("Selected hotel has been deleted successfully.");
                            alert.showAndWait();
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Deletion error");
                            alert.setContentText("An error occurred while deleting the hotel.");
                            alert.showAndWait();
                        }
                    }else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("No selection");
                        alert.setContentText("Please select a hotel to delete.");
                        alert.showAndWait();

                    }
                }
            }
        });

    }

    @FXML
    private void onEditHotel() {
        LuksuzniHotel selectedHotel = tablicaHotela.getSelectionModel().getSelectedItem();
        if (selectedHotel != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("EditHotelPopup.fxml"));
                Parent root = loader.load();
                EditHotelController controller = loader.getController();
                controller.setHotel(selectedHotel);

                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setTitle("Edit Hotel");
                stage.setScene(new Scene(root));
                stage.showAndWait();
                tablicaHotela.refresh();
            } catch (IOException e) {
                e.printStackTrace();
                // Handle the exception
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Loading error");
                alert.setContentText("An error occurred while loading the edit popup.");
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No selection");
            alert.setContentText("Please select a hotel to edit.");
            alert.showAndWait();
        }
    }
}
