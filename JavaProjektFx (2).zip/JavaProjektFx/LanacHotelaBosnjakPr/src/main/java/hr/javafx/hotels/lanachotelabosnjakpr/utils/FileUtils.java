package hr.javafx.hotels.lanachotelabosnjakpr.utils;

import hr.javafx.hotels.lanachotelabosnjakpr.Promjena;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtils implements FileUtilsExchangeData {

    private static final String imeFilea = "filePromjene.ser";
    private static final Logger log = LoggerFactory.getLogger(FileUtils.class);


    @Override
    public void spremiPromjenu(Promjena promjena) {

        PromjenePair<List<Promjena>,Promjena> promjenePair=new PromjenePair<>( dohvatiPromjene(),promjena);

        try (FileOutputStream fileOutputStream = new FileOutputStream(imeFilea);
             ObjectOutputStream ous = new ObjectOutputStream(fileOutputStream)) {
            ous.writeObject(promjenePair.getBoth());
        } catch (FileNotFoundException e) {
            log.error("File not found", e);
        } catch (IOException e) {
            log.error("I/O error", e);
        }
    }

    @Override
    public List<Promjena> dohvatiPromjene() {
        List<Promjena> novaPR = new ArrayList<>();
        File file = new File(imeFilea);
        if (!file.exists()) {
            return novaPR;
        }

        try (FileInputStream fileis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fileis)) {
            novaPR = (List<Promjena>) ois.readObject();
        } catch (EOFException e) {
            return novaPR;
        } catch (IOException | ClassNotFoundException e) {
            log.error("Error occurred while dohvatiPromjene", e);
        }
        return novaPR;
    }
}
