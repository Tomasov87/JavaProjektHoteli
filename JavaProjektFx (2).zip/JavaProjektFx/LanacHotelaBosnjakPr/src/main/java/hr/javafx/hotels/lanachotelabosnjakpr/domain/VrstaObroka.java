package hr.javafx.hotels.lanachotelabosnjakpr.domain;

import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.NepoznatiKodVrsteObrokaException;

public enum VrstaObroka {
    RIBA (1),
    MESO (2),
    VEGE (3);


    private Integer kodVrste;



    public static VrstaObroka fromName(String name) {
        for (VrstaObroka vrstaObrok : VrstaObroka.values()) {
            if (vrstaObrok.name().equals(name)) {
                return vrstaObrok;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + name);
    }

    public static VrstaObroka fromCode(Integer code) throws NepoznatiKodVrsteObrokaException {
        for (VrstaObroka vrstaObrok : VrstaObroka.values()) {
            if (vrstaObrok.getKodVrste().equals(code)) {
                return vrstaObrok;
            }
        }
        throw new NepoznatiKodVrsteObrokaException("Unknown code: " + code);
    }

    VrstaObroka(int kodVrste) {
        this.kodVrste = kodVrste;
    }

    public Integer getKodVrste() {
        return kodVrste;
    }

    public void setKodVrste(Integer kodVrste) {
        this.kodVrste = kodVrste;
    }
}
