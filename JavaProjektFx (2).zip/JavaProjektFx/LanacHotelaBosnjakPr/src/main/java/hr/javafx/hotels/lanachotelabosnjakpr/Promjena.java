package hr.javafx.hotels.lanachotelabosnjakpr;

import java.io.Serializable;
import java.time.LocalDate;

public class Promjena implements Serializable {
    private String opisPromjene;
    private LocalDate vrijeme;

    private String user;

    public Promjena(String opisPromjene, LocalDate vrijeme, String user) {
        this.opisPromjene = opisPromjene;
        this.vrijeme = vrijeme;
        this.user = user;
    }

    public String getOpisPromjene() {
        return opisPromjene;
    }

    public void setOpisPromjene(String opisPromjene) {
        this.opisPromjene = opisPromjene;
    }

    @Override
    public String toString() {
        return user + " " + vrijeme + " " + opisPromjene;
    }

    public LocalDate getVrijeme() {
        return vrijeme;
    }

    public String getUser() {
        return user;
    }
}
