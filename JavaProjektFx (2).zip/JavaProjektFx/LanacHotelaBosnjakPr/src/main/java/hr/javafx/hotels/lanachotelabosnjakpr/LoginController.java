package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.LoginFailedException;
import hr.javafx.hotels.lanachotelabosnjakpr.login.LoginBuilder;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameTextField;
    @FXML
    private PasswordField passField;

    public static String userRole;

    public void login() {
        String username = usernameTextField.getText();
        String pass = passField.getText();

        if (username.isEmpty() || pass.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesite sve podatke");

            alert.showAndWait();

            return;

        }
        LoginBuilder.Login login=LoginBuilder.newBuilder().username(username).password(pass).build();
        String role;
        try {
            role = login.login(username, pass);
        } catch (LoginFailedException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ne postoji takav korisnik!");
            alert.setContentText("Molimo Vas unesite korisnika koji postoji");
            alert.showAndWait();
            return;
        }


        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Login uspješan!");
        alert.setContentText("Podaci su uspješno uneseni");
        alert.showAndWait();
        userRole = role;
        showUnosLuxHotela();


    }


    public void showUnosLuxHotela() {

        {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("luksuzniHotelUnos.fxml"));

            try {
                Scene scene = new Scene(fxmlLoader.load(), 600, 400);
                HelloApplication.getMainStage().setTitle("Obicna soba unos!");
                HelloApplication.getMainStage().setScene(scene);
                HelloApplication.getMainStage().show();
            } catch (IOException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Neuspjesno otvaranje file-a!");
                alert.showAndWait();
            }


        }


    }
}
