package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.LuksuzniHotel;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.RazinaObroka;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.StandardniHotel;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class PregledStandardnogHotela {


    @FXML
    TableColumn<StandardniHotel, String> imeColumn;

    @FXML
    TableColumn<StandardniHotel, String> gradColumn;

    @FXML
    TableColumn<StandardniHotel, String> cijenaColumn;

    @FXML
    TableColumn<StandardniHotel, String> datumColumn;

    @FXML
    TableColumn<StandardniHotel, Integer> zvjezdiceColumn;

    @FXML
    TableColumn<StandardniHotel, String> obrokColumn;

    @FXML
    TableView<StandardniHotel> tablicaHotela;

    @FXML
    private TextField zvjezdiceFilter;
    @FXML
    private TextField cijenaFilter;

    @FXML
    private TextField imeHotelaFilter;

    List<StandardniHotel> listaStanHotela;

    @FXML
    public void initialize(){

        listaStanHotela = DatabaseUtils.getStandardniHotel();
        imeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getImeHotela()));
        gradColumn.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getGrad()));
        cijenaColumn.setCellValueFactory(cellData->new SimpleObjectProperty<>(cellData.getValue().getPrice().toString()));
        datumColumn.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getDatumPrijave().toString()));
        zvjezdiceColumn.setCellValueFactory(cellData->new SimpleIntegerProperty(cellData.getValue().getZvjezdice().getBrojZvj()).asObject());
        obrokColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getRazinaPrehrane().toString()));


        ObservableList<StandardniHotel> observableStanHotel = FXCollections.observableArrayList(listaStanHotela);

        tablicaHotela.setItems(observableStanHotel);
    }


    public void filterStanHotele(){
        String imeFilter = imeHotelaFilter.getText();
        String cijenaFilt = cijenaFilter.getText();
        String zvjFilter = zvjezdiceFilter.getText();

        if(listaStanHotela.isEmpty()){
            return;
        }

        if (imeFilter.isEmpty()){
            imeFilter = "";
        }

        if (cijenaFilt.isEmpty()){
            cijenaFilt = "";
        }

        if (zvjFilter.isEmpty()){
            zvjFilter = "";
        }


        String finalImeFilter = imeFilter;
        String finalCijenaFilter = cijenaFilt;
        String finalZvjFilter = zvjFilter;

        List<StandardniHotel> filtriranaLista;

        BigDecimal konvCijena = null;
        Integer konvZvj = null;

        try{
            if (!finalCijenaFilter.isEmpty()){
                konvCijena = new BigDecimal(finalCijenaFilter);
            }
            if (!finalZvjFilter.isEmpty()){
                konvZvj = Integer.parseInt(finalZvjFilter);
            }
            // konvZvj = Integer.parseInt(finalZvjFilter);
        }catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesie broj!");
            alert.showAndWait();
            return;

        }



        filtriranaLista = listaStanHotela.stream().filter(x -> x.getImeHotela().contains(finalImeFilter)).collect(Collectors.toList());

        BigDecimal finalKonvCijena = konvCijena;
        if (finalKonvCijena != null){
            if (filtriranaLista == null){
                filtriranaLista = listaStanHotela;
            }
            filtriranaLista = filtriranaLista.stream() .filter(x ->x.getPrice().equals(finalKonvCijena)).collect(Collectors.toList());
        }


        Integer finalKonvZvj = konvZvj;
        if (finalKonvZvj != null){
            if (filtriranaLista == null){
                filtriranaLista = listaStanHotela;
            }

            filtriranaLista = filtriranaLista.stream().filter(x ->x.getZvjezdice().getBrojZvj().equals(finalKonvZvj)).collect(Collectors.toList());
        }

        ObservableList<StandardniHotel> filtriranaObservableLista = FXCollections.observableArrayList(filtriranaLista);

        tablicaHotela.setItems(filtriranaObservableLista);
    }

    @FXML
    private void onDeleteHotel() {
        Alert popup = new Alert(Alert.AlertType.CONFIRMATION);
        popup.setTitle("Confirmation");
        popup.setContentText("Are you sure you want to delete the hotel?");
        popup.showAndWait().ifPresent(new Consumer<ButtonType>() {
            @Override
            public void accept(ButtonType buttonType) {
                if (buttonType == ButtonType.OK) {
                    StandardniHotel selectedHotel = tablicaHotela.getSelectionModel().getSelectedItem();
                    if (selectedHotel != null) {
                        boolean success = DatabaseUtils.deleteStandardniHotel(selectedHotel);
                        if (success) {
                            listaStanHotela.remove(selectedHotel);
                            tablicaHotela.getItems().remove(selectedHotel);
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Hotel deleted");
                            alert.setContentText("Selected hotel has been deleted successfully.");
                            alert.showAndWait();
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Deletion error");
                            alert.setContentText("An error occurred while deleting the hotel.");
                            alert.showAndWait();
                        }
                    }else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("No selection");
                        alert.setContentText("Please select a hotel to delete.");
                        alert.showAndWait();

                    }
                }
            }
        });

    }

    @FXML
    private void onEditHotel() {
        StandardniHotel selectedHotel = tablicaHotela.getSelectionModel().getSelectedItem();
        if (selectedHotel != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("EditStandardniHotelPopup.fxml"));
                Parent root = loader.load();
                EditStandardniHotelController controller = loader.getController();
                controller.setHotel(selectedHotel);

                Stage stage = new Stage();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setTitle("Edit Hotel");
                stage.setScene(new Scene(root));
                stage.showAndWait();
                tablicaHotela.refresh();
            } catch (IOException e) {
                e.printStackTrace();
                // Handle the exception
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Loading error");
                alert.setContentText("An error occurred while loading the edit popup.");
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No selection");
            alert.setContentText("Please select a hotel to edit.");
            alert.showAndWait();
        }
    }
}
