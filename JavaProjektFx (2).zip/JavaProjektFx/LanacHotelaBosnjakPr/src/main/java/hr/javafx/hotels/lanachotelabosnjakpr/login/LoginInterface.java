package hr.javafx.hotels.lanachotelabosnjakpr.login;

import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.LoginFailedException;

public sealed interface LoginInterface permits LoginBuilder.Login{
      String login(String username, String password) throws LoginFailedException;
}
