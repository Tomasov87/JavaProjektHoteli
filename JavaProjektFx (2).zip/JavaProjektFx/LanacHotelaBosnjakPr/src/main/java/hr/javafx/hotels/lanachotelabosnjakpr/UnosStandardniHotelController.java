package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.*;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class UnosStandardniHotelController {
    @FXML
    private TextField imeTextField;

    @FXML
    private TextField gradTextField;

    @FXML
    private TextField cijenaTextField;

    @FXML
    private TextField zvijezdiceTextField;

    @FXML
    private ComboBox<RazinaObroka> razinaObrokaComboBox;

    @FXML
    private ListView<Radnik> poljeRadnika;

    @FXML
    private DatePicker datumPrijave;


    public void initialize() {
        List<Radnik> listaRadnika = DatabaseUtils.getRadnici();

        ObservableList<Radnik> observableListRadnika = FXCollections.observableArrayList(listaRadnika);
        poljeRadnika.setItems(observableListRadnika);

        poljeRadnika.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);


        List<RazinaObroka> listaObroka = DatabaseUtils.getRazinaObroka();

        ObservableList<RazinaObroka> observableListRazina = FXCollections.observableArrayList(listaObroka);

        razinaObrokaComboBox.setItems(observableListRazina);
    }

    public void unosStanHotel() {

        String imeHotela = imeTextField.getText();
        String grad = gradTextField.getText();
        String cijena = cijenaTextField.getText();
        String zvijezdice = zvijezdiceTextField.getText();
        RazinaObroka obrok = razinaObrokaComboBox.getValue();
        LocalDate datum = datumPrijave.getValue();

        ObservableList<Radnik> observableLista = poljeRadnika.getSelectionModel().getSelectedItems();

        Set<Radnik> radniciSet = new HashSet<>(observableLista);

        if (imeHotela.isEmpty() || grad.isEmpty() || cijena.isEmpty() || zvijezdice.isEmpty() || (obrok == null) || datum == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesite sve podatke");

            alert.showAndWait();

            return;
        }

        Integer brZvjezdica;
        BigDecimal cijenaKonv;
        try {
            brZvjezdica = Integer.parseInt(zvijezdice);
            cijenaKonv = new BigDecimal(cijena);

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesie broj!");
            alert.showAndWait();
            return;
        }

        StandardniHotel standardniHotel = new StandardniHotel(0, imeHotela, grad, cijenaKonv, datum, Zvjezdice.fromCode(brZvjezdica), radniciSet, obrok);

        if (DatabaseUtils.saveStandardniHotel(standardniHotel)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Uspješan unos!");
            alert.setContentText("Podaci uspješno uneseni!");
            alert.showAndWait();
            FileUtils fileUtils = new FileUtils();
            fileUtils.spremiPromjenu(new Promjena("Unjeli smo novi standardni hotel, naziva" + " " + imeHotela, LocalDate.now(), LoginController.userRole));
            return;
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Nešto ste krivo unjeli");
            alert.showAndWait();
            return;
        }
    }


}
