package hr.javafx.hotels.lanachotelabosnjakpr.utils;

import hr.javafx.hotels.lanachotelabosnjakpr.Promjena;

import java.util.List;

public interface FileUtilsExchangeData {
    void spremiPromjenu(Promjena promjena);
    List<Promjena> dohvatiPromjene();
}
