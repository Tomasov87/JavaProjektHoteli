package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.login.LoginBuilder;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

// HelloApplication.java
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloApplication extends Application {
    public static Stage mainStage;

    @Override
    public void start(Stage stage) throws IOException {
        mainStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login" +
                ".fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        HelloApplication.getMainStage().sizeToScene();
        stage.setTitle("Hoteli");
        stage.setScene(scene);
        stage.show();
    }

//tomi pass: t
    //standard user: tt pass: pp


    public static Stage getMainStage(){
        return mainStage;
    }

    public static void main(String[] args) {
     /*   LoginBuilder.Login login=LoginBuilder.newBuilder().username("tt").password("pp").role("standard").build();
      */
        launch();
    }
}
