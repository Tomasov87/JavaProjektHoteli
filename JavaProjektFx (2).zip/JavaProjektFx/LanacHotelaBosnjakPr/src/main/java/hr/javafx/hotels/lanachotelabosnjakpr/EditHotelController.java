package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.LuksuzniHotel;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.Zvjezdice;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.util.Optional;

public class EditHotelController {

    @FXML
    private TextField imeHotelaField;
    @FXML
    private TextField gradField;
    @FXML
    private TextField cijenaField;
    @FXML
    private DatePicker datumField;
    @FXML
    private TextField zvjezdiceField;
    @FXML
    private TextField kvadratiField;

    private LuksuzniHotel hotel;

    public void setHotel(LuksuzniHotel hotel) {
        this.hotel = hotel;
        imeHotelaField.setText(hotel.getImeHotela());
        gradField.setText(hotel.getGrad());
        cijenaField.setText(hotel.getPrice().toString());
        datumField.setValue(hotel.getDatumPrijave());
        zvjezdiceField.setText(String.valueOf(hotel.getZvjezdice().getBrojZvj()));
        kvadratiField.setText(String.valueOf(hotel.getBrojKvadrata()));
    }

    @FXML
    private void onSave() {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Save Changes");
        confirmationAlert.setContentText("Are you sure you want to save the changes?");

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                hotel.setImeHotela(imeHotelaField.getText());
                hotel.setGrad(gradField.getText());
                hotel.setPrice(new BigDecimal(cijenaField.getText()));
                hotel.setDatumPrijave(datumField.getValue());
                hotel.setZvjezdice(Zvjezdice.fromCode(Integer.parseInt(zvjezdiceField.getText())));
                hotel.setBrojKvadrata(Double.parseDouble(kvadratiField.getText()));

                boolean success = DatabaseUtils.updateLuksuzniHotel(hotel);
                if (success) {
                    closeWindow();
                } else {
                    showErrorAlert("Save error", "An error occurred while saving the hotel details.");
                }
            } catch (Exception e) {
                showErrorAlert("Input error", "Please check the input fields for valid data.");
            }
        }
    }

    @FXML
    private void onCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) imeHotelaField.getScene().getWindow();
        stage.close();
    }

    private void showErrorAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
