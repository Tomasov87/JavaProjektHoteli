package hr.javafx.hotels.lanachotelabosnjakpr.utils;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.*;
import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.NepoznatiKodVrsteObrokaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

public class DatabaseUtils {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseUtils.class);
    public static final String DATABASE_FILE = "C:\\Users\\tomab\\Desktop\\JAVA\\JavaProjektFx\\LanacHotelaBosnjakPr\\conf\\database.properties";


    private static Connection connectToDatabase() throws SQLException, IOException {
        Properties svojstva = new Properties();
        String urlBazePodataka = svojstva.getProperty("databaseUrl");
        String korisnickoIme = svojstva.getProperty("username");
        String lozinka = svojstva.getProperty("password");
        svojstva.load(new FileReader(DATABASE_FILE));
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection veza = DriverManager.getConnection("jdbc:mysql://localhost:3306/java",
                    "root", "");

            //System.out.println("Connected to the database!");

            return veza;

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection failed!");
            e.printStackTrace();
        }
            return null;

    }

    public static boolean saveRazinaObroka(RazinaObroka razinaObroka) {

        try (Connection connection = connectToDatabase()) {

            String insertRazinaObrokaSql = "INSERT INTO razina_obroka(razina, vrstaObroka) VALUES(?, ?);";
            PreparedStatement pstmt = connection.prepareStatement(insertRazinaObrokaSql);
            pstmt.setInt(1, razinaObroka.kolicina());
            pstmt.setInt(2, razinaObroka.vrstaObroka().getKodVrste());
            pstmt.execute();
            return true;


        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod spremanja podataka u bazu!";
            logger.error(message, ex);
            System.out.println(message);
        }

        return false;
    }

    public static void saveLuksuzniHotel(LuksuzniHotel luksuzniHotel) {
        try (Connection connection = connectToDatabase()) {
            String insertHotelSql = "INSERT INTO luksuzni_hotel(ZVIJEZDICE, IMEHOTELA, GRAD, CIJENA," +
                    "DATE, BROJKVADRATA) VALUES(?, ?, ?, ?, ?, ?);";
            PreparedStatement pstmt = connection.prepareStatement(insertHotelSql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, luksuzniHotel.getZvjezdice().getBrojZvj());
            pstmt.setString(2, luksuzniHotel.getImeHotela());
            pstmt.setString(3, luksuzniHotel.getGrad());
            pstmt.setBigDecimal(4, luksuzniHotel.getPrice());
            pstmt.setDate(5, new Date(luksuzniHotel.getDatumPrijave().atStartOfDay().atZone(
                    ZoneId.systemDefault()).toInstant().toEpochMilli()));
            pstmt.setInt(6, luksuzniHotel.getBrojKvadrata().intValue());

            Integer affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {

                ResultSet rs = pstmt.getGeneratedKeys();

                if (rs.next()) {

                    int luksuzniHotelId = rs.getInt(1);
                    for (Radnik radnik : luksuzniHotel.getListaRadnika()) {

                        String updateRadniciSql = "UPDATE radnici SET luksuzniHotelId = ? WHERE id = ?";
                        PreparedStatement pstmt1 = connection.prepareStatement(updateRadniciSql);

                        pstmt1.setInt(1, luksuzniHotelId);
                        pstmt1.setInt(2, radnik.getId());
                        pstmt1.execute();
                    }
                }
            }


        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod spremanja podataka u bazu!";
            logger.error(message, ex);
            System.out.println(message);
        }
    }


    public static boolean saveStandardniHotel(StandardniHotel standardniHotel) {
        try (Connection connection = connectToDatabase()) {

            String insertHotelSql = "INSERT INTO standardni_hotel(IMEHOTELA, GRAD, CIJENA," +
                    "datumPrijave, zvjezdice, razinaobrokaId) VALUES(?, ?, ?, ?, ?, ?);";
            PreparedStatement pstmt = connection.prepareStatement(insertHotelSql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, standardniHotel.getImeHotela());
            pstmt.setString(2, standardniHotel.getGrad());
            pstmt.setDouble(3, standardniHotel.getPrice().doubleValue());
            pstmt.setDate(4, new Date(standardniHotel.getDatumPrijave().atStartOfDay().atZone(
                    ZoneId.systemDefault()).toInstant().toEpochMilli()));
            pstmt.setInt(5, standardniHotel.getZvjezdice().getBrojZvj());
            pstmt.setInt(6, standardniHotel.getRazinaPrehrane().id());
            Integer affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {

                ResultSet rs = pstmt.getGeneratedKeys();

                if (rs.next()) {

                    int standardniHotelId = rs.getInt(1);
                    for (Radnik radnik : standardniHotel.getListaRadnika()) {

                        String updateRadniciSql = "UPDATE radnici SET standardniHotelId = ? WHERE id = ?";
                        PreparedStatement pstmt1 = connection.prepareStatement(updateRadniciSql);

                        pstmt1.setInt(1, standardniHotelId);
                        pstmt1.setInt(2, radnik.getId());
                        pstmt1.execute();
                    }
                }
            }

            return true;

        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod spremanja podataka u bazu!";
            logger.error(message, ex);
            System.out.println(message);
        }

        return false;
    }


    public static boolean saveRadnik(Radnik radnik) {
        try (Connection connection = connectToDatabase()) {

            String insertHotelSql = "INSERT INTO radnici(ime, prezime, opisposla) VALUES(?, ?, ?);";
            PreparedStatement pstmt = connection.prepareStatement(insertHotelSql);
            pstmt.setString(1, radnik.getIme());
            pstmt.setString(2, radnik.getPrezime());
            pstmt.setString(3, radnik.getOpisPosla());
            pstmt.execute();
            return true;


        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod spremanja podataka u bazu!";
            logger.error(message, ex);
            System.out.println(message);
        }

        return false;
    }


    public static List<Radnik> getRadnici() {

        List<Radnik> radnici = new ArrayList<>();

        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM radnici";
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                Integer id = rs.getInt("id");
                String ime = rs.getString("ime");
                String prezime = rs.getString("prezime");
                String opisPosla = rs.getString("opisPosla");

                Radnik<String> radnik = new Radnik<>(ime, prezime, opisPosla, id);
                radnici.add(radnik);
            }
            return radnici;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        }
        return new ArrayList<>();

    }


    public static List<RazinaObroka> getRazinaObroka() {

        List<RazinaObroka> razinaObrokaLista = new ArrayList<>();

        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM razina_obroka";
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                Integer razina = rs.getInt("razina");
                Integer vrstaObroka = rs.getInt("vrstaObroka");
                Integer idObroka = rs.getInt("id");


                RazinaObroka razinaObroka = new RazinaObroka(idObroka, razina, VrstaObroka.fromCode(vrstaObroka));
                razinaObrokaLista.add(razinaObroka);
            }
            return razinaObrokaLista;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        } catch (NepoznatiKodVrsteObrokaException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja koda vrste obroka iz baze!";
            logger.error(message, ex);
        }
        return new ArrayList<>();

    }


    public static List<LuksuzniHotel> getLuksuzniHotel() {

        List<LuksuzniHotel> luksuzniHotelLista = new ArrayList<>();

        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM luksuzni_hotel";
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                String imeHotela = rs.getString("imeHotela");
                String grad = rs.getString("grad");
                Double cijena = rs.getDouble("cijena");
                Date datum = rs.getDate("date");
                Integer zvijezdice = rs.getInt("zvijezdice");
                Double brojKvadrata = rs.getDouble("brojKvadrata");
                Integer id = rs.getInt("id");

                Set<Radnik> radniciSet = new HashSet<>(getRadniciInHotel(id, true));
                LuksuzniHotel luksuzniHotel = new LuksuzniHotel(id, imeHotela, grad, new BigDecimal(cijena),
                        datum.toLocalDate(), Zvjezdice.fromCode(zvijezdice), radniciSet, brojKvadrata);
                luksuzniHotelLista.add(luksuzniHotel);
            }
            return luksuzniHotelLista;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        }
        return new ArrayList<>();
    }

    public static boolean updateLuksuzniHotel(LuksuzniHotel hotel) {
        try (Connection connection = connectToDatabase()) {
            PreparedStatement stmt = null;
            String sql = "UPDATE luksuzni_hotel SET imehotela=?, grad=?, cijena=?, date=?, zvijezdice=?, brojKvadrata=? WHERE id=?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, hotel.getImeHotela());
            stmt.setString(2, hotel.getGrad());
            stmt.setBigDecimal(3, hotel.getPrice());
            stmt.setDate(4, new Date(hotel.getDatumPrijave().atStartOfDay().atZone(
                    ZoneId.systemDefault()).toInstant().toEpochMilli()));
            stmt.setInt(5, hotel.getZvjezdice().getBrojZvj());
            stmt.setDouble(6, hotel.getBrojKvadrata());
            stmt.setInt(7, hotel.getId());

            stmt.execute();
            return true;
        } catch (SQLException | IOException e) {
            logger.error("Error occured while updating luksuzni hotel",e);
        }
        return false;
    }

    public static boolean updateStandardniHotel(StandardniHotel hotel) {
        try (Connection connection = connectToDatabase()) {
            PreparedStatement stmt = null;
            String sql = "UPDATE standardni_hotel SET imehotela=?, grad=?, cijena=?, datumprijave=?, zvjezdice=?, razinaobrokaid=? WHERE id=?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, hotel.getImeHotela());
            stmt.setString(2, hotel.getGrad());
            stmt.setBigDecimal(3, hotel.getPrice());
            stmt.setDate(4, new Date(hotel.getDatumPrijave().atStartOfDay().atZone(
                    ZoneId.systemDefault()).toInstant().toEpochMilli()));
            stmt.setInt(5, hotel.getZvjezdice().getBrojZvj());
            System.out.println(hotel.getRazinaPrehrane().id());
            stmt.setInt(6, hotel.getRazinaPrehrane().id());
            stmt.setInt(7, hotel.getId());

            stmt.execute();
            return true;
        } catch (SQLException | IOException e) {
            logger.error("Error occured while updating luksuzni hotel",e);
        }
        return false;
    }

    public static boolean deleteLuksuzniHotel(LuksuzniHotel luksuzniHotel) {
        try (Connection connection = connectToDatabase()) {
            PreparedStatement stmt = null;
            String radnikSql = "UPDATE radnici SET luksuzniHotelId = NULL WHERE id=?";
            for (Radnik radnik : luksuzniHotel.getListaRadnika()) {
                stmt = connection.prepareStatement(radnikSql);
                stmt.setInt(1, radnik.getId());
                stmt.executeUpdate();
            }
            String sql = "DELETE FROM luksuzni_hotel WHERE id=?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, luksuzniHotel.getId());

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                return true;
            }
        } catch (IOException | SQLException e) {
            logger.error("Error occurred while deleting luksuzni hotel",e);
        }
        return false;
    }


    public static boolean deleteStandardniHotel(StandardniHotel standardniHotel) {
        try (Connection connection = connectToDatabase()) {
            PreparedStatement stmt = null;
            String radnikSql = "UPDATE radnici SET standardniHotelId = NULL WHERE id=?";
            for (Radnik radnik : standardniHotel.getListaRadnika()) {
                stmt = connection.prepareStatement(radnikSql);
                stmt.setInt(1, radnik.getId());
                stmt.executeUpdate();
            }
            String sql = "DELETE FROM standardni_hotel WHERE id=?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, standardniHotel.getId());

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                return true;
            }
        } catch (IOException | SQLException e) {
            logger.error("Error occurred while deleting standardni hotel",e);
        }
        return false;
    }


    public static List<StandardniHotel> getStandardniHotel() {

        List<StandardniHotel> standardniHotelLista = new ArrayList<>();

        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM standardni_hotel";
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                String imeHotela = rs.getString("imeHotela");
                String grad = rs.getString("grad");
                Double cijena = rs.getDouble("cijena");
                Date datum = rs.getDate("datumPrijave");
                Integer zvijezdice = rs.getInt("zvjezdice");
                Integer id = rs.getInt("id");
                Integer razinaObrokaId = rs.getInt("razinaObrokaId");

                RazinaObroka razinaObrokaStandardniHotel = getRazinaObrokaInStandardniHotel(razinaObrokaId);

                Set<Radnik> radniciSet = new HashSet<>(getRadniciInHotel(id, false));
                StandardniHotel standardniHotel = new StandardniHotel(id, imeHotela, grad, new BigDecimal(cijena),
                        datum.toLocalDate(), Zvjezdice.fromCode(zvijezdice), radniciSet, razinaObrokaStandardniHotel);
                standardniHotelLista.add(standardniHotel);
            }
            return standardniHotelLista;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        }
        return new ArrayList<>();
    }


    public static RazinaObroka getRazinaObrokaInStandardniHotel(Integer id) {


        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM razina_obroka JOIN standardni_hotel ON razina_obroka.id = " + id;
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            rs.next();

            Integer razina = rs.getInt("razina");
            Integer vrstaObroka = rs.getInt("vrstaObroka");
            Integer idObroka = rs.getInt("id");

            RazinaObroka razinaObroka = new RazinaObroka(idObroka, razina, VrstaObroka.fromCode(vrstaObroka));


            return razinaObroka;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        } catch (NepoznatiKodVrsteObrokaException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja koda vrste obroka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        }
        return null;

    }

    public static List<Radnik> getRadniciInHotel(Integer id, boolean isLuksuzniHotel) {

        List<Radnik> radnici = new ArrayList<>();

        try (Connection connection = connectToDatabase()) {
            String sqlQuery = "SELECT * FROM radnici";
            if (isLuksuzniHotel) {
                sqlQuery = sqlQuery + " JOIN LUKSUZNI_HOTEL ON RADNICI.LUKSUZNIHOTELID = " + id;
            } else {
                sqlQuery = sqlQuery + " JOIN STANDARDNI_HOTEL ON RADNICI.STANDARDNIHOTELID = " + id;
            }
            Statement stmt = connection.createStatement();
            stmt.execute(sqlQuery);
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                Integer idRadnika = rs.getInt("id");
                String ime = rs.getString("ime");
                String prezime = rs.getString("prezime");
                String opisPosla = rs.getString("opisPosla");

                Radnik<String> radnik = new Radnik<>(ime, prezime, opisPosla, idRadnika);
                radnici.add(radnik);
            }
            return radnici;
        } catch (SQLException | IOException ex) {
            String message = "Dogodila se pogreška kod dohvaćanja podataka iz baze!";
            logger.error(message, ex);
            System.out.println(message);
        }
        return new ArrayList<>();

    }


}
