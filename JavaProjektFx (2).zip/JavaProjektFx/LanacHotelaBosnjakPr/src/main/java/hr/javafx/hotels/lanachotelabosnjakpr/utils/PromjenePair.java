package hr.javafx.hotels.lanachotelabosnjakpr.utils;

import hr.javafx.hotels.lanachotelabosnjakpr.Promjena;

import java.util.ArrayList;
import java.util.List;

public class PromjenePair<T, K> {

    private T listPromjena;
    private K singlePromjena;

    public PromjenePair(T listPromjena, K singlePromjena) {
        this.listPromjena = listPromjena;
        this.singlePromjena = singlePromjena;
    }

    public T getListPromjena() {
        return listPromjena;
    }

    public void setListPromjena(T listPromjena) {
        this.listPromjena = listPromjena;
    }

    public K getSinglePromjena() {
        return singlePromjena;
    }

    public void setSinglePromjena(K singlePromjena) {
        this.singlePromjena = singlePromjena;
    }

    public List<Promjena> getBoth() {
        List<Promjena> combinedList = new ArrayList<>();
        if (listPromjena instanceof List) {
            for (Object item : (List<?>) listPromjena) {
                if (item instanceof Promjena) {
                    combinedList.add((Promjena) item);
                }
            }
        } else if (listPromjena instanceof Promjena) {
            combinedList.add((Promjena) listPromjena);
        }

        if (singlePromjena instanceof Promjena) {
            combinedList.add((Promjena) singlePromjena);
        }

        return combinedList;
    }
}
