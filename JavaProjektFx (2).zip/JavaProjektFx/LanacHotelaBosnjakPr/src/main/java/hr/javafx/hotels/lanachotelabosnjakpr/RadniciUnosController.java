package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.Zvjezdice;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.time.LocalDate;

public class RadniciUnosController {
    @FXML
    private TextField imeTextField;
    @FXML
    private TextField prezimeTextField;
    @FXML
    private TextField opisPoslaTextField1;

    public void unosRadnika(){
        String imeRadnika = imeTextField.getText();
        String prezimeRadnika = prezimeTextField.getText();
        String opisPosla = opisPoslaTextField1.getText();

        if(imeRadnika.isEmpty() || prezimeRadnika.isEmpty() || opisPosla.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesite sve podatke");

            alert.showAndWait();

            return;
        }

        Radnik <String> radnik = new Radnik<>(imeRadnika, prezimeRadnika, opisPosla);
        if(DatabaseUtils.saveRadnik(radnik)== true) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Unos uspješan!");
            alert.setContentText("Podaci su uspješno uneseni");
            alert.showAndWait();
            FileUtils fileUtils = new FileUtils();
            fileUtils.spremiPromjenu(new Promjena("Unjeli smo novog radnika, imena" + " " + imeRadnika, LocalDate.now(), LoginController.userRole));

        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Podaci nisu uneseni, došlo je do greške");
            alert.showAndWait();
        }
    }
}
