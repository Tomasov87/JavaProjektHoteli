package hr.javafx.hotels.lanachotelabosnjakpr.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

public class LuksuzniHotel extends Hotel implements Serializable {

    private Double brojKvadrata;

    public LuksuzniHotel(Integer id, String imeHotela, String grad, BigDecimal price, LocalDate datumPrijave, Zvjezdice zvjezdice, Set<Radnik> listaRadnika, Double brojKvadrata) {
        super(id, imeHotela, grad, price, datumPrijave, zvjezdice, listaRadnika);
        this.brojKvadrata = brojKvadrata;
    }

    public Double getBrojKvadrata() {
        return brojKvadrata;
    }

    public void setBrojKvadrata(Double brojKvadrata) {
        this.brojKvadrata = brojKvadrata;
    }
}
