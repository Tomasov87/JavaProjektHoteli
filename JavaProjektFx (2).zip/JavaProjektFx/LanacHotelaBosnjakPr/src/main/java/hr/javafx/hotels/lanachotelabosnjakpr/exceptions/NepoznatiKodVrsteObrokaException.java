package hr.javafx.hotels.lanachotelabosnjakpr.exceptions;

public class NepoznatiKodVrsteObrokaException extends Exception{
    public NepoznatiKodVrsteObrokaException(String message) {
        super(message);
    }

    public NepoznatiKodVrsteObrokaException(String message, Throwable cause) {
        super(message, cause);
    }

    public NepoznatiKodVrsteObrokaException(Throwable cause) {
        super(cause);
    }
}
