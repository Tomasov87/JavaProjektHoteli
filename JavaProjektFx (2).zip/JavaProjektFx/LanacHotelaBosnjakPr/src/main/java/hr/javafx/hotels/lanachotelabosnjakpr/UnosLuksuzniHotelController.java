package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.LuksuzniHotel;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.Zvjezdice;
import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.NedovoljnoRadnikaException;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class UnosLuksuzniHotelController {

    @FXML
    private TextField imeTextField;

    @FXML
    private TextField gradTextField;

    @FXML
    private TextField cijenaTextField;

    @FXML
    private TextField zvijezdiceTextField;

    @FXML
    private TextField brojKvadrataTextField;

    @FXML
    private ListView<Radnik> poljeRadnika;

    @FXML
    private DatePicker datumPrijave;


    public void initialize() {
        List<Radnik> listaRadnika = DatabaseUtils.getRadnici();

        ObservableList<Radnik> observableListRadnika = FXCollections.observableArrayList(listaRadnika);
        poljeRadnika.setItems(observableListRadnika);

        poljeRadnika.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void unosLuksHotel() {
        try {
            String imeHotela = imeTextField.getText();
            String grad = gradTextField.getText();
            String cijena = cijenaTextField.getText();
            String zvijezdice = zvijezdiceTextField.getText();
            String kvadrati = brojKvadrataTextField.getText();
            LocalDate datum = datumPrijave.getValue();

            ObservableList<Radnik> observableLista = poljeRadnika.getSelectionModel().getSelectedItems();

            Set<Radnik> radniciSet = new HashSet<>(observableLista);
            if (radniciSet.isEmpty()) {
                throw new NedovoljnoRadnikaException("Potrebno je više od nula radnika za rad hotela!");
            }

            if (imeHotela.isEmpty() || grad.isEmpty() || cijena.isEmpty() || zvijezdice.isEmpty() || kvadrati.isEmpty() || datum == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Krivi unos!");
                alert.setContentText("Molimo Vas unesite sve podatke");

                alert.showAndWait();

                return;
            }

            Integer brZvjezdica;
            Double brKvadrati;
            BigDecimal cijenaKonv;

            try {
                brZvjezdica = Integer.parseInt(zvijezdice);
                brKvadrati = Double.parseDouble(kvadrati);
                cijenaKonv = new BigDecimal(cijena);

            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Krivi unos!");
                alert.setContentText("Molimo Vas unesie broj!");
                alert.showAndWait();
                return;
            }

            LuksuzniHotel luksuzniHotel = new LuksuzniHotel(0, imeHotela, grad, cijenaKonv, datum, Zvjezdice.fromCode(brZvjezdica), radniciSet, brKvadrati);
            DatabaseUtils.saveLuksuzniHotel(luksuzniHotel);

            FileUtils fileUtils = new FileUtils();
            fileUtils.spremiPromjenu(new Promjena("Unjeli smo novi hotel, naziva" + " " + imeHotela, LocalDate.now(), LoginController.userRole));
        } catch (NedovoljnoRadnikaException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas izaberite dovoljan broj radnika!");
            alert.showAndWait();
        }
    }


}
