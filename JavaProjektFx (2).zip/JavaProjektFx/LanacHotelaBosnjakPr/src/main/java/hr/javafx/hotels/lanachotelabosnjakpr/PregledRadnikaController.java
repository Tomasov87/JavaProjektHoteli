package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.PrazanFilterRadnikaException;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PregledRadnikaController {

    @FXML
    TableColumn<Radnik, String> imeRadnikaColumn;

    @FXML
    TableColumn<Radnik, String> prezimeRadnikaColumn;

    @FXML
    TableColumn<Radnik, String> vrstaPoslaColumn;

    @FXML
    private TextField filtriranjeImeTextField;
    @FXML
    private TextField filtriranjePosoTextField;

    List<Radnik> listaRadnika;

    @FXML
    TableView<Radnik> tablicaRadnika;


    @FXML
    public void initialize() {
        listaRadnika = DatabaseUtils.getRadnici();
        imeRadnikaColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIme()));
        prezimeRadnikaColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPrezime()));
        vrstaPoslaColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getOpisPosla()));

        ObservableList<Radnik> observableListaRadnika = FXCollections.observableArrayList(listaRadnika);

        tablicaRadnika.setItems(observableListaRadnika);
    }


    public void onFilterClick() {
        try {
            String imeFilter = filtriranjeImeTextField.getText();
            String opisPoslaFilter = filtriranjePosoTextField.getText();

            if (imeFilter.isEmpty() && opisPoslaFilter.isEmpty()) {
                throw new PrazanFilterRadnikaException("Potrebna polja filtera, vracamo izvorne podatke");
            }

            if (listaRadnika.isEmpty()) {
                return;
            }

            if (imeFilter.isEmpty()) {
                imeFilter = "";
            }

            if (opisPoslaFilter.isEmpty()) {
                opisPoslaFilter = "";
            }

            String finalImeFilter = imeFilter;
            String finalOpisPoslaFilter = opisPoslaFilter;
            List<Radnik> filtriranaLista;


            filtriranaLista = listaRadnika.stream().filter(x -> x.getIme().contains(finalImeFilter)).filter(x -> x.getOpisPosla().contains(finalOpisPoslaFilter)).collect(Collectors.toList());

            ObservableList<Radnik> filtriranaObservableLista = FXCollections.observableArrayList(filtriranaLista);

            tablicaRadnika.setItems(filtriranaObservableLista);
        } catch (PrazanFilterRadnikaException e) {
            ObservableList<Radnik> observableListaRadnika = FXCollections.observableArrayList(listaRadnika);
            tablicaRadnika.setItems(observableListaRadnika);
        }
    }

}
