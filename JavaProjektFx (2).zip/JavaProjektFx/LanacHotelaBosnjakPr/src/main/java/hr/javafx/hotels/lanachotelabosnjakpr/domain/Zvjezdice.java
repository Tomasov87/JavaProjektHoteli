package hr.javafx.hotels.lanachotelabosnjakpr.domain;

public enum Zvjezdice {
    JEDNA (1),
    DVIJE (2),
    TRI (3),
    CETIRI (4),
    PET(5);

    private Integer brojZvj;


    public static Zvjezdice fromCode(Integer code) {
        for (Zvjezdice zvjezdice : Zvjezdice.values()) {
            if (zvjezdice.getBrojZvj().equals(code)) {
                return zvjezdice;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }

    Zvjezdice(Integer brojZvj) {
        this.brojZvj = brojZvj;
    }

    public Integer getBrojZvj() {
        return brojZvj;
    }

}