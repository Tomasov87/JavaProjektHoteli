package hr.javafx.hotels.lanachotelabosnjakpr;

import hr.javafx.hotels.lanachotelabosnjakpr.domain.Radnik;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.RazinaObroka;
import hr.javafx.hotels.lanachotelabosnjakpr.domain.VrstaObroka;
import hr.javafx.hotels.lanachotelabosnjakpr.utils.DatabaseUtils;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PregledJelaController {

    @FXML
    TableColumn<RazinaObroka, String> vrstaJelaColumn;

    @FXML
    TableColumn<RazinaObroka, Integer> razinaColumn;

    @FXML
    ComboBox<VrstaObroka> vrstaObrokaComboBox;

    @FXML
    TableView<RazinaObroka> tablicaJela;

   // Map<VrstaObroka, List<RazinaObroka>> razinaObroka = new HashMap<>();

    List<RazinaObroka> listaJela;


    @FXML
    public void initialize() {
        listaJela = DatabaseUtils.getRazinaObroka();
        razinaColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().kolicina()).asObject());
        vrstaJelaColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().vrstaObroka().name()));

        ObservableList<RazinaObroka> observableRazinaObroka = FXCollections.observableArrayList(listaJela);
        ObservableList<VrstaObroka> vrstaObrokas = FXCollections.observableArrayList(VrstaObroka.values());
        vrstaObrokaComboBox.setItems(vrstaObrokas);
        tablicaJela.setItems(observableRazinaObroka);
    }

    @FXML
    public void filterVrstaJela() {
        List<RazinaObroka> filteredList = new ArrayList<>();
        VrstaObroka vrstaObroka = vrstaObrokaComboBox.getValue();
        if (vrstaObroka == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Krivi unos!");
            alert.setContentText("Molimo Vas unesite sve podatke");

            alert.showAndWait();
        }
        filteredList = listaJela.stream().filter(x -> x.vrstaObroka().equals(vrstaObroka)).collect(Collectors.toUnmodifiableList());
        ObservableList<RazinaObroka> razinaObrokas= FXCollections.observableArrayList(filteredList);
        tablicaJela.setItems(razinaObrokas);
    }


}
