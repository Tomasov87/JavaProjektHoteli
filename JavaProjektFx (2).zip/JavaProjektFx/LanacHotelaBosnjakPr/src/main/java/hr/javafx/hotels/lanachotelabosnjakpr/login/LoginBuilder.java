package hr.javafx.hotels.lanachotelabosnjakpr.login;

import hr.javafx.hotels.lanachotelabosnjakpr.exceptions.LoginFailedException;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Optional;

public class LoginBuilder {

    private static final String LOGIN_FILE = "infoLogin.txt";

    private LoginBuilder() {
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {

        private String username;
        private String password;
        private String role;

        private Builder() {
            // Default constructor
        }

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Login build() {
            Login login = new Login();
            login.initializeFile();
            if (username != null && password != null && role != null) {
                login.addUser(username, password, role);
            }
            return login;
        }
    }

    public static final class Login implements LoginInterface {
        private Login() {
        }

        private void initializeFile() {
            File file = new File(LOGIN_FILE);
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String hashPassword(String password) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(password.getBytes());
                StringBuilder sb = new StringBuilder();
                for (byte b : hash) {
                    sb.append(String.format("%02x", b));
                }
                return sb.toString();
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }

        private void addUser(String username, String password, String role) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOGIN_FILE, true))) {
                String hashedPassword = hashPassword(password);
                writer.write(username + "," + hashedPassword + "," + role);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public String login(String username, String password) throws LoginFailedException {
            String hashedPassword = hashPassword(password);
            Optional<String> role = findRoleInFile(username, hashedPassword);
            if (role.isEmpty()) {
                throw new LoginFailedException("Username or password is incorrect");
            }
            return role.orElse(null);
        }

        private Optional<String> findRoleInFile(String username, String hashedPassword) {
            try (BufferedReader reader = new BufferedReader(new FileReader(LOGIN_FILE))) {
                return reader.lines()
                        .map(line -> line.split(","))
                        .filter(loginInfo -> loginInfo[0].equals(username) && loginInfo[1].equals(hashedPassword))
                        .map(credentials -> credentials[2])
                        .findFirst();
            } catch (IOException e) {
                e.printStackTrace();
                return Optional.empty();
            }
        }
    }
}
